ACORN-SAT v2 station data for 112 sites listed in acorn_sat_v2_stations.txt
Metadata catalogue identifier http://www.bom.gov.au/metadata/19115/ANZCW0503900447 
Australian Bureau of Meteorology 

